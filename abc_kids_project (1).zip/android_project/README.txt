# ABC Kids - Android Project Source (Ready to Build APK)

This folder contains the complete Android Studio / Gradle project source.

### How to build APK in Android Studio:
1. Open Android Studio.
2. Click **File -> New -> Import Project** and choose this folder.
3. Assets (`index.html`, `manifest.json`, `icon.svg`, `sw.js`) are located in `src/main/assets/`.
4. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
5. Your signed/debug APK will be ready in `build/outputs/apk/debug/`.
